# Query removed, see https://github.com/joomla/joomla-cms/pull/25177
